package autocropping;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;


public class Files {
    
    protected String path;
    protected int pixeladjust;
    
    public void setPath(String p)
    {path = p + "\\";}
    public String getPath()
    {return path;}
    
    public void setPixelAdjust(int pix)
    {pixeladjust = pix;}
    public int getPixelAdjust()
    {return pixeladjust;}
    
    
    
    public Files(String p,int pixel)
    {path = p;
     pixeladjust = pixel;}
    public Files(){}
    
    public ArrayList<String> ReadFileWriteToArray(String pathName) throws FileNotFoundException
    {
        ArrayList<String> arrList;
        try (Scanner newFile = new Scanner(new File(pathName)).useDelimiter("\n")) {
            arrList = new ArrayList<>();
            while(newFile.hasNext())
            {
                arrList.add(newFile.next());
            }
        }
        
        return arrList;
    }
    
    public static void displayArrayList(ArrayList<String> arr)
    {
        arr.stream().forEach((value) -> {
            System.out.println(value);
        });
    }
    
    public void writeArrayToFile(ArrayList<String> arr, String file, Files f) throws IOException
    {
        try (FileWriter writer = new FileWriter(file)) {
            for (String str: arr)
            {
                writer.write("convert " + f.getPath()+ str + " -virtual-pixel White -blur 0x15 -fuzz 15%% -trim info: >> " + f.getPath()+ "info.txt\n" );
            }
            writer.close();
        }
        
    }
    
    public void writeListFile(String file) throws IOException
    {
        try (FileWriter writer = new FileWriter(file + "info.bat")) {
            writer.write ("cd " + file + "\n");
            writer.write("dir /b *.tif > filename.txt");
            writer.close();
        }
        
    }
   
    public void writeFinalScriptfromArray(ArrayList<String> arr, Files f) throws IOException
    {
        FileWriter writer = new FileWriter(getPath() + "script.bat");
        
        String filename,croppedfilename;
        int topleftX, topleftY,x,y,maxX,maxY;
        for (int i = 0 ; i < arr.size(); i++)
        {
            String[] temp = arr.get(i).split(" ");
            
            //getFilename
            filename = temp[0];
            filename = filename.replace(f.getPath(),"");
            //Modify -> cropped filename
            //croppedfilename = filename.split("\\.")[0] + "_cropped.tif";
            croppedfilename = "cropped\\"+filename;
            
            //get x,y
            String[] xy = temp[2].split("x");
            x = Integer.parseInt(xy[0]) + 2*getPixelAdjust();
            y = Integer.parseInt(xy[1]) + 2*getPixelAdjust();
            
            String[] coor = temp[3].split("[\\D]");
            maxX = Integer.parseInt(coor[0]);
            maxY = Integer.parseInt(coor[1]);
            topleftX = Integer.parseInt(coor[2]) - getPixelAdjust();
            topleftY = Integer.parseInt(coor[3]) - getPixelAdjust();  
            if (topleftX < 0)
                topleftX = 0;
            if (topleftY < 0)
                topleftY = 0;
            if (Integer.parseInt(coor[2]) < getPixelAdjust())
                x = x - getPixelAdjust();
            if (Integer.parseInt(coor[3]) < getPixelAdjust())
                y = y - getPixelAdjust();
            
//            System.out.println(x + " " + y);
//            System.out.println(topleftX + " " + topleftY);
//            System.out.println(maxX +  " " + maxY);
            writer.write("convert " + f.getPath()+filename + " -crop " + x + "x" + y + "+" + topleftX + "+" + topleftY + " " + f.getPath()+croppedfilename + "\n");           
        }
        writer.close();
    }
    
    public void Analyzing(Files f) throws IOException
    {
                //GET LIST OF FILE IN THE FOLDER
        f.writeListFile(f.getPath());
        run("cmd","/c",f.getPath() + "info.bat");
               
             
        //READ FILENAME TO ARRAY
        ArrayList<String> arr = f.ReadFileWriteToArray(f.getPath() + "filename.txt");
        //System.in.read();
        
        //write information command to .bat file
        f.writeArrayToFile(arr,f.getPath() + "fileinfo.bat",f);
        run("cmd","/c",f.getPath()+"fileinfo.bat");
        
        //wait - analyzing....
        //System.in.read();
        
        //Get information command and write to array
        ArrayList<String> arrScript = f.ReadFileWriteToArray(f.getPath() + "info.txt");
        
        //System.in.read();
        //Write to .bat to crop
        f.writeFinalScriptfromArray(arrScript,f);
        
    }
    
    public void Cropping(Files f) throws IOException
    {
        run("cmd","/c","mkdir",f.getPath()+"cropped");
        run("cmd","/c",f.getPath()+"script.bat");
                
        //clean 
        run ("cmd","/c","del",f.getPath()+"info.bat",f.getPath()+"info.txt",f.getPath()+"fileinfo.bat",f.getPath()+"filename.txt",f.getPath()+"script.bat");
        
    }
    
    
//    public static void main(String s[]) throws FileNotFoundException, IOException, InterruptedException
//    {
//        String fullpath = "C:\\Maps";
//        fullpath = fullpath + "\\";
//        File dir1 = new File(".");
//        fullpath = dir1.getCanonicalPath()  + "\\";
//        
//        
//        int safe_space = 25;
////        
////        Scanner a = new Scanner(System.in);
////        System.out.println("Enter directory of destination:");
////        fullpath = a.nextLine();
////        System.out.println("Path is: " + fullpath);
////        System.out.println("Enter safe-space in pixel (default 25px):");
////        safe_space = a.nextInt();
////        System.out.println("Safe-space is:" + safe_space);
////        Files f = new Files(fullpath,safe_space);
//        
//        //SET PATH AND SAFE-SPACE
//        Files f = new Files(fullpath,safe_space);
//        
//        
//        
//        //GET LIST OF FILE IN THE FOLDER
//        f.writeListFile(f.getPath());
//        
//        run("cmd","/c",f.getPath()+"info.bat");
//        
//             
//        //READ FILENAME TO ARRAY
//        ArrayList<String> arr = f.ReadFileWriteToArray(f.getPath() + "filename.txt");
//        //System.in.read();
//        
//        //write information command to .bat file
//        f.writeArrayToFile(arr,f.getPath() + "fileinfo.bat",f);
//        run("cmd","/c",f.getPath()+"fileinfo.bat");
//        
//        //wait - analyzing....
//        //System.in.read();
//        
//        //Get information command and write to array
//        ArrayList<String> arrScript = f.ReadFileWriteToArray(f.getPath() + "info.txt");
//        
//        //System.in.read();
//        run("cmd","/c","mkdir",f.getPath()+"cropped");
//        //Write to .bat to crop
//        f.writeFinalScriptfromArray(arrScript,f);
//        
//        run("cmd","/c",f.getPath()+"script.bat");
//        
//        
//        //clean 
//        run ("cmd","/c","del",f.getPath()+"info.bat",f.getPath()+"info.txt",f.getPath()+"fileinfo.bat",f.getPath()+"filename.txt",f.getPath()+"script.bat");
//        
//        
//    }
    
    //RUN CMD ARGUMENTS
    public static void run(String... command) throws IOException {
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            InputStream is = p.getInputStream();
            System.out.println("\nCommand " + Arrays.asList(command) + " reported");
            int b;
            while ((b = is.read()) >= 0)
                System.out.write(b);
            is.close();
            p.destroy();
        } catch (IOException e) {
            System.err.println("\nCommand " + Arrays.asList(command) + " reported " + e);
        }
    }
}
