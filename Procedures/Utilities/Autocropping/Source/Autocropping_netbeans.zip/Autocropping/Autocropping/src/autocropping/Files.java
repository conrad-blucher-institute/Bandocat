package autocropping;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;


public class Files {
    public ArrayList<String> ReadFileToArray(String pathName) throws FileNotFoundException
    {
        Scanner newFile = new Scanner(new File(pathName));
        ArrayList<String> arrList = new ArrayList<String>();
        while(newFile.hasNext())
        {
            arrList.add(newFile.next());
        }
        newFile.close();
        
        return arrList;
    }
    
    public static void displayArrayList(ArrayList<String> arr)
    {
        for (String value : arr) {
            System.out.println(value);
        }
    }
    
    public void writeArrayToFile(ArrayList<String> arr, String file) throws IOException
    {
        FileWriter writer = new FileWriter(file);
        for (String str: arr)
        {
            writer.write("convert " + str + " -virtual-pixel edge -blur 0x15 -fuzz 15%% -trim info: >> info.txt\n" );
        }
        writer.close();
        
    }
    
    public void writeListFile(String file) throws IOException
    {
        FileWriter writer = new FileWriter(file + "info.bat");
        writer.write ("cd " + file + "\n");
        writer.write("dir /b *.tif > filename.txt");
        writer.close();
        
    }
    
    
    
    public static void main(String s[]) throws FileNotFoundException, IOException
    {
        
        Files f = new Files();
        
        f.writeListFile("C:\\Program Files\\ImageMagick-6.8.5-Q16\\images\\test\\");
        //String[] command = {"cmd", "/c", "C:\\Program Files\\ImageMagick-6.8.5-Q16\\images\\test\\info.bat"};
        //Runtime.getRuntime().exec(command);
        //ArrayList<String> arr = f.ReadFileToArray("C:\\Program Files\\ImageMagick-6.8.5-Q16\\images\\test\\filename.txt");
        //f.writeArrayToFile(arr,"C:\\Program Files\\ImageMagick-6.8.5-Q16\\images\\test\\fileinfo.bat");
        
        
        
    }
    
}
